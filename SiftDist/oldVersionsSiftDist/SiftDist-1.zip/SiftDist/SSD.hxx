// Copyright (2008), The Hebrew University of Jerusalem.
// All Rights Reserved.

// Created by Ofir Pele
// The Hebrew University of Jerusalem

// This software for computing the SiftDist distance between histograms is being
// made available for individual non-profit research use only. Any commercial use
// of this software requires a license from the Hebrew University of Jerusalem.

// For further details on obtaining a commercial license, contact Ofir Pele
// (ofirpele@cs.huji.ac.il) or Yissum, the technology transfer company of the
// Hebrew University of Jerusalem.

// THE HEBREW UNIVERSITY OF JERUSALEM MAKES NO REPRESENTATIONS OR WARRANTIES OF
// ANY KIND CONCERNING THIS SOFTWARE.

// IN NO EVENT SHALL THE HEBREW UNIVERSITY OF JERUSALEM BE LIABLE TO ANY PARTY FOR
// DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST
// PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF
// THE THE HEBREW UNIVERSITY OF JERUSALEM HAS BEEN ADVISED OF THE POSSIBILITY OF
// SUCH DAMAGE. THE HEBREW UNIVERSITY OF JERUSALEM SPECIFICALLY DISCLAIMS ANY
// WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
// MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE SOFTWARE PROVIDED
// HEREUNDER IS ON AN "AS IS" BASIS, AND THE HEBREW UNIVERSITY OF JERUSALEM HAS NO
// OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR
// MODIFICATIONS.

#ifndef _OFIRPELE_SSD__HXX
#define _OFIRPELE_SSD__HXX

/// This class has operator() which returns the SSD between two SIFT-like histograms
///
///@param NUM_T the type of numbers. Must be signed. Its zero
/// value must be defined in NumTypeZero.hxx
template<typename NUM_T>
class SSD {
            
public:

      /// Ctor that gets the sift bins number. Should be greater than 1. 
      SSD(unsigned int SIFT_BINS_NUM) : _SIFT_BINS_NUM(SIFT_BINS_NUM), NUM_T_ZERO(NumTypeZero<NUM_T>::ZERO()) {
      	    assert(SIFT_BINS_NUM>1);
      } // SSD
      
      /// Returns the SSD between the two SIFT-like
      /// histograms descriptors sift1, sift2.
      /// Where each histogram contains CELLS_NUM cells
      /// and each cell contains NBO orientation bins.
      /// The dimension that goes fastest is the NBO.
      /// i.e. sift1 looks like:
      /// x_1_1, x_1_2, ... x_1_NBO, x_2_1, ...
      ///
      /// @param sift1 the first SIFT-like histogram.
      /// @param sift2 the second SIFT-like histogram.
      /// @param NBO the number of orientation bins
      /// (original SIFT had 8 bins)
      /// NBO has to be greater than 1.
      /// @param CELLS_NUM the number of spatial cells.
      /// Regular SIFT has 4x4=16 cells.
      /// CELLS_NUM has to be greater than 0.
      /// 
      /// Note: NBO*CELLS_NUM should be equal to the SIFT_BINS_NUM given in ctor.
      /// In this distance NBO, CELLS_NUM are not used.
      NUM_T operator()(const NUM_T* sift1, 
		       const NUM_T* sift2,
		       unsigned int NBO,
		       unsigned int CELLS_NUM) {

	    assert(NBO*CELLS_NUM==_SIFT_BINS_NUM);
	    
	    _dist= NUM_T_ZERO;

	    for (unsigned int i=0; i<_SIFT_BINS_NUM; ++i) {
		  NUM_T tmp= sift1[i]-sift2[i];
		  _dist+= tmp*tmp;
	    } // i
	    	    
	    return _dist;
	    
      } // operator()
      

private:
	    
      NUM_T _dist;
      unsigned int _SIFT_BINS_NUM;
      const NUM_T NUM_T_ZERO;

}; // end class SSD

#endif
