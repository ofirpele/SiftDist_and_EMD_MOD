mex -O -DNDEBUG SiftDist.cxx
mex -O -DNDEBUG SiftRatioMatch.cxx

