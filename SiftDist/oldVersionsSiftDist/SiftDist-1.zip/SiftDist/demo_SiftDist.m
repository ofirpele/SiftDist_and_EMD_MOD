% SiftDist_demo Demonstrate SiftDist.  
%   This demo computes the sift descriptor on a pair of well known
%   test images. Then it matches them using SiftDist.

clc;

fprintf(2,'The script calls functions from Andrea Vedaldi`s sift code.\n');
fprintf(2,'You need to:\n');
fprintf(2,' 1. download his code from:\n');
  
fprintf(2,'    a. http://vision.ucla.edu/~vedaldi/code/sift/assets/sift/binaries/  \n');
fprintf(2,'       ( it contains already compiled binaries, for the source code see: )\n');
fprintf(2,'       ( http://vision.ucla.edu/~vedaldi/code/sift/assets/sift/versions/ )\n');
fprintf(2,' 2. Unzip the file.\n');
fprintf(2,' 3. Change the path below to the directory in which Andrea Vedaldi`s sift code is.\n');

%addpath full_path_to_Andrea_Vedaldi_code;
addpath /cs/vis/ofirpele/moz_downloades/tmp/sift

% Increase value to decrease the number of matches (and possibly better matches).
RATIO_THRESH= 1.25;

I1=imreadbw('img1.ppm');
I2=imreadbw('img3.ppm');

I1=I1-min(I1(:));
I1=I1/max(I1(:));
I2=I2-min(I2(:));
I2=I2/max(I2(:));

fprintf('Computing frames and descriptors (~0.5 minutes).\n');
[frames1,descr1]= sift(I1, 'NumOrientBins', 16);
[frames2,descr2]= sift(I2, 'NumOrientBins', 16);


fprintf('Matches using SiftDist (~3 minutes).\n');
tic
[inds ratios] = SiftRatioMatch(descr1, frames1, descr2, frames2);
inds_r= inds;
inds_r(ratios<RATIO_THRESH)= 0;


% Transform to Andrea's Vedaldi's matches format
matches= zeros(2,sum(inds_r~=0));
i= 1;
for r=1:size(descr1,2)
  if (inds_r(r)~=0)
    matches(1,i)= r;
    matches(2,i)= inds_r(r);
    i=i+1;
  end
end

figure; clf;
title('Click on a keypoint to see its match'); axis off;
plotmatches(I1, I2, frames1(1:2,:), frames2(1:2,:), matches, 'Interactive', 2);
drawnow;


